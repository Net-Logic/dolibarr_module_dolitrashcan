
## v1.0.2 (2022-11-30)

#### :rocket: Enhancement
* [#27](https://github.com/Net-Logic/dolibarr_module_dolitrashcan/pull/27) Changelog auto ([@frederic34](https://github.com/frederic34))
* [#24](https://github.com/Net-Logic/dolibarr_module_dolitrashcan/pull/24) test ([@frederic34](https://github.com/frederic34))
* [#23](https://github.com/Net-Logic/dolibarr_module_dolitrashcan/pull/23) Workb ([@frederic34](https://github.com/frederic34))

#### :memo: Documentation
* [#28](https://github.com/Net-Logic/dolibarr_module_dolitrashcan/pull/28) Work on changelog ([@frederic34](https://github.com/frederic34))
* [#22](https://github.com/Net-Logic/dolibarr_module_dolitrashcan/pull/22) auto translation ([@frederic34](https://github.com/frederic34))

#### Committers: 1
- Frédéric FRANCE ([@frederic34](https://github.com/frederic34))
